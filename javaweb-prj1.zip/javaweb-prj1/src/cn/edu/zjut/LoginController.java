package cn.edu.zjut;
import java.io.*; 
import javax.servlet.*; 
import javax.servlet.http.*;
import cn.edu.zjut.model.*;
import cn.edu.zjut.dao.UserDao; 
/*ʵ��1����*/
/*public class LoginController extends HttpServlet 
{
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
	response.setContentType("text/html;charset=utf-8"); 
	PrintWriter out=response.getWriter(); 
	String username = request.getParameter("username"); 
	String password = request.getParameter("password");
	if("zjut".equals(username) && "zjut".equals(password)){ 
		out.println("��¼�ɹ�����ӭ����"); }
	else{ 
		out.println("�û������������");
			}
		} 
	}*/
public class LoginController extends HttpServlet 
{
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
	String username = request.getParameter("username"); 
	String password = request.getParameter("password");
	int type = Integer.parseInt(request.getParameter("type"));
	UserBean user=new UserBean(); 
	user.setUsername(username); 
	user.setPassword(password);
	user.setType(type);
	if(checkUser(user)){ 
		request.setAttribute("USER", user); 
		RequestDispatcher dispatcher = request .getRequestDispatcher("/loginSuccess.jsp"); 
		dispatcher.forward(request, response); 
		}else{
			response.sendRedirect("/javaweb-prj1/loginFailed.jsp"); } 
			}
	//ʵ�������
	/*boolean checkUser(UserBean user){ 
	if("zjut".equals(user.getUsername()) && "zjut".equals(user.getPassword())&&user.getType()==1){ 
		return true; }
	else{ 
		return false; } 
	}}*/
	boolean checkUser(UserBean user){ 
		UserDao ud=new UserDao(); 
		if( ud.searchUser(user) ) {
			return true; 
			}
		return false; } 
}