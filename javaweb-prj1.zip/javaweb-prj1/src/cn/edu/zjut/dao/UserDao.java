package cn.edu.zjut.dao;
import java.sql.*;
import javax.sql.*;
import java.sql.Connection;
import javax.naming.*;
import cn.edu.zjut.model.UserBean;
public class UserDao {
	public UserDao(){};
	private static final String GET_ONE_SQL = "SELECT * FROM usertable WHERE username=? and password=?"; 
	
	public Connection getConnection(){ 
		Connection conn = null; String driver = "com.microsoft.jdbc.sqlserver.SQLServerDriver"; 
		String dburl = "jdbc:microsoft:sqlserver://localhost:1433;databaseName=myDB"; 
		String username = "dbuser"; //���ݿ��¼�û��� 
		String password = "dbpassword"; //���ݿ��¼����
		try{ Class.forName(driver); //�������ݿ��������� 
		conn = DriverManager.getConnection(dburl,username,password); }
		catch( Exception e ){ e.printStackTrace(); } 
		return conn; }
	public boolean searchUser(UserBean user){ // ���û���������У���û��Ƿ�Ϸ� 
		Connection conn = null; 
		PreparedStatement pstmt = null; 
		ResultSet rst=null; 
		try{
			conn = getConnection(); 
			pstmt = conn.prepareStatement(GET_ONE_SQL);
			pstmt.setString(1, user.getUsername()); 
			pstmt.setString(2, user.getPassword()); 
			rst = pstmt.executeQuery(); 
			if(rst.next()){ 
				if(rst.getInt("type")==user.getType()) return true;
				else return false;} 
			}catch(SQLException se){ 
				se.printStackTrace();
				return false; }
		finally{ 
			try{
				pstmt.close();
				conn.close(); }
			catch(SQLException se){
				se.printStackTrace();
				} 
			}
		return false; }
	
	public boolean addUser(UserBean userBean) {   //�����û�
		String sql="insert into usertable values(?,?,?)";
		Connection connection;
		try {
			connection = getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, userBean.getUsername());
			preparedStatement.setString(2, userBean.getPassword());
			preparedStatement.setInt(3, userBean.getType());
			preparedStatement.executeUpdate();
			connection.close();
			return true;
	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return false;
		
	} 
	}

	

