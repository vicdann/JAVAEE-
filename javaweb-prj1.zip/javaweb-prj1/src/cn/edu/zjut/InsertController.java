package cn.edu.zjut;
import java.io.*; 
import javax.servlet.*; 
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
import cn.edu.zjut.model.*;
import cn.edu.zjut.dao.UserDao;
/**
 * Servlet implementation class InsertController
 */
@WebServlet("/InsertController")
public class InsertController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public InsertController() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String username,password;
		int type=2;//��ͨ�û�
		username=request.getParameter("username");
		password=request.getParameter("password");
		UserBean userbean=new UserBean();
		userbean.setUsername(username);
		userbean.setPassword(password);
		userbean.setType(type);
		UserDao ud=new UserDao();
		
		if(ud.addUser(userbean)) {
			request.setAttribute("USER", userbean);
			RequestDispatcher r=request.getRequestDispatcher("/registersuccess.jsp");
			r.forward(request, response);
		}
		else {
			System.out.println("ע��ʧ��");
		}
		
		
	}

}
